---
name: Q and A, or Other
about: Use this to ask a question, not related to a specific bug nor feature request. (Note our contributor agreement at https://github.com/verilator/verilator/blob/master/docs/CONTRIBUTING.rst)
title: ''
labels: new
assignees: ''

---

How may we help - what is your question?

(If reporting a bug or requesting a feature please hit BACK on your browser and use a different issue templates.)
