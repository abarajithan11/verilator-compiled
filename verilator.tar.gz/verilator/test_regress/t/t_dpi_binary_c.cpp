// -*- mode: C++; c-file-style: "cc-mode" -*-
//*************************************************************************
//
// Copyright 2009-2009 by Wilson Snyder. This program is free software; you can
// redistribute it and/or modify it under the terms of either the GNU
// Lesser General Public License Version 3 or the Perl Artistic License
// Version 2.0.
// SPDX-License-Identifier: LGPL-3.0-only OR Artistic-2.0
//
//*************************************************************************

#include "t_dpi_binary_c.h"

#include "svdpi.h"

#include <cstdio>

//======================================================================

extern "C" void dpic_final();

void dpic_final() {
    printf("%s:\n", __func__);
    printf("*-* All Finished *-*\n");
}
